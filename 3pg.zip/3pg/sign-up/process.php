<?php

$pgscp = $_GET['step'];